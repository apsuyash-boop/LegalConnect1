const mongoose = require("mongoose");
const bcrypt = require("bcrypt");

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: [true, "Please enter your Username"],
  },
  email: {
    type: String,
    required: [true, "Please enter your Email"],
    unqiue: true,
    lowercase: true,
  },
  password: {
    type: String,
    required: [true, "Please enter your Password"],
    minLength: [6, "Minimum password length should be 6"],
  },
  role: {
    type: String,
    enum: ["client", "admin", "lawyer"],
    default: "client",
  },
});

userSchema.pre("save", async function () {
  if (!this.isModified("password")) return;

  const salt = await bcrypt.genSalt();
  this.password = await bcrypt.hash(this.password, salt);
});

userSchema.statics.login = async function (email, password) {

    const user = await this.findOne({ email });

    if (user) {

        const auth = await bcrypt.compare(password, user.password);

        if (auth) {
            return user;
        }

        throw Error("Incorrect Password");
    }

    throw Error("Incorrect User");
};

const User = mongoose.model("user", userSchema);

module.exports = User;
