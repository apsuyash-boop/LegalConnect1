const mongoose = require("mongoose");

const clientSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "user",
    required: true,
  },

  name: {
    type: String,
    required: true,
  },

  email: {
    type: String,
    required: true,
  },

  phone: {
    type: String,
    required: true,
  },

  about: {
    type: String,
    required: true,
  },

  legalCategory: {
    type: [String],
    default: [],
  },

  opponentType: {
    type: String,
  },

  urgency: {
    type: String,
  },

  consultationMode: {
    type: [String],
    default: [],
  },

  budget: {
    type: Number,
  },

  preferredLanguage: {
    type: [String],
    default: [],
  },

  preferredCity: {
    type: String,
  },

  caseFiled: {
    type: String,
  },

  courtLevel: {
    type: String,
  },

  additionalNotes: {
    type: String,
  },

  aiSummary: {
    type: String,
    default: "",
  },

  recommendedLawyers: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "lawyer",
    },
  ],
}, {
  timestamps: true,
});

const Client = mongoose.model('client' , clientSchema);
module.exports = Client;