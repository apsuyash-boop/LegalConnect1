const mongoose = require('mongoose');

const lawyerSchema = new mongoose.Schema({
    userId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"user",
        required:true
    },
    name:{
        type:String,
    },
    phone:{
        type:String
    },
    about:{
        type:String,
    },
    experience:{
        type:Number
    },
    specialization:{
        type:[String]
    },
    court:{
        type:String,
    },
    qualification:{
        type:String,
    },
    barCouncilNumber: {
    type: String
},

barCouncilState: {
    type: String
},

languages: {
    type: [String]
},

consultationFee: {
    type: Number
},

address: {
    type: String
},

city: {
    type: String
},

state: {
    type: String
},

pincode: {
    type: String
},

consultationMode: {
    type: [String]
},

availableDays: {
    type: [String]
},

availableTime: {
    type: String
},

rating: {
    type: Number,
    default: 0
},

totalReviews: {
    type: Number,
    default: 0
},

isVerified: {
    type: Boolean,
    default: false
},

},{
        timestamps: true
    });

const Lawyer = mongoose.model("lawyer" , lawyerSchema);

module.exports = Lawyer;