const mongoose = require("mongoose");

const consultationSchema = new mongoose.Schema({

    clientId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"user",
        required:true
    },

    lawyerId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"user",
        required:true
    },

    clientProfile:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"client",
        required:true
    },

    lawyerProfile:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"lawyer",
        required:true
    },

    status:{
        type:String,
        enum:["Pending","Accepted","Rejected"],
        default:"Pending"
    },

    message:{
        type:String,
        default:""
    },

    createdAt:{
        type:Date,
        default:Date.now
    }

});

const Consult = mongoose.model("consultation",consultationSchema);
module.exports = Consult;