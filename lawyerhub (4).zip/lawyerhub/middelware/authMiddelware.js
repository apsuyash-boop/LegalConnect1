const jwt = require("jsonwebtoken");
const User = require("../models/User");

const requiredAuth = (req, res, next) => {
  const token = req.cookies.jwt;

  if (token) {
    jwt.verify(token, "ishan", (err, decodedtoken) => {
      if (err) {
        res.redirect("/login");
      } else {
        console.log(decodedtoken);
        next();
      }
    });
  } else {
    res.redirect("/login");
  }
};

const currentuser = (req, res, next) => {
  const token = req.cookies.jwt;

  if (!token) {
    res.locals.user = null;
    req.user = null;
    return next();
  }

  jwt.verify(token, "ishan", async (err, decodedtoken) => {
    if (err) {
      res.locals.user = null;
      req.user = null;
      return next();
    }

    try {
      const user = await User.findById(decodedtoken.id);

      if (!user) {
        res.locals.user = null;
        req.user = null;
        return next();
      }

      res.locals.user = user;
      req.user = user;
      next();
    } catch (err) {
      console.log(err);
      res.locals.user = null;
      req.user = null;
      next();
    }
  });
};
const requiredLawyer = (req, res, next) => {
  const token = req.cookies.jwt;
  if (token) {
    jwt.verify(token, "ishan", async (err, decodedtoken) => {
      if (err) {
        console.log(err.message);
        res.locals.user = null;
        next();
      } else {
        console.log(decodedtoken);
        let user = await User.findById(decodedtoken.id);
        if (user.role === "lawyer") {
          next();
        } else {
          res.redirect("/client");
        }
      }
    });
  }
  else{
    res.redirect('/')
  }
};

const requiredClient = (req, res, next) => {
  const token = req.cookies.jwt;
  if (token) {
    jwt.verify(token, "ishan", async (err, decodedtoken) => {
      if (err) {
        console.log(err.message);
        res.locals.user = null;
        next();
      } else {
        console.log(decodedtoken);
        let user = await User.findById(decodedtoken.id);
        if (user.role === "client") {
          next();
        } else {
          res.redirect("/lawyer");
        }
      }
    });
  }
  else{
    res.redirect('/')
  }
};

module.exports = { requiredAuth, currentuser, requiredLawyer , requiredClient };
