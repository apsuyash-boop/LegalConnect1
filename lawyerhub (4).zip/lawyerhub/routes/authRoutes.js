const {Router} = require('express');
const authcontroller = require('../controller/authControllers');
const {requiredAuth} = require('../middelware/authMiddelware');
const {requiredLawyer} = require('../middelware/authMiddelware');
const {requiredClient} = require('../middelware/authMiddelware');

const routes = Router();

routes.get('/', authcontroller.home_get);
routes.get('/about', authcontroller.about);
routes.get('/contact', authcontroller.contact);


routes.get('/signup' , authcontroller.signup_get);
routes.post('/signup' , authcontroller.signup_post);




routes.get('/login' , authcontroller.login_get);
routes.post('/login' , authcontroller.login_post);


routes.get('/logout' ,authcontroller.logout_get);

routes.get('/client' ,requiredAuth,requiredClient ,authcontroller.client_get);
routes.post('/client/profile' ,requiredAuth,requiredClient , authcontroller.client_profile_post)
routes.get('/client/lawyer' ,requiredAuth,requiredClient , authcontroller.client_lawyer_get)


routes.post("/client/request/:lawyerId",requiredClient,authcontroller.requestConsultation);




routes.get('/lawyer' ,requiredAuth,requiredLawyer ,authcontroller.lawyer_get);
routes.post('/lawyer/profile' ,requiredAuth,requiredLawyer , authcontroller.lawyer_profile_post)

routes.get("/lawyer/requests",requiredAuth,requiredLawyer,authcontroller.lawyer_requests_get);
routes.get("/lawyer/:id", authcontroller.viewLawyerProfile);

routes.post('/lawyer/request/accept/:id' , requiredAuth,requiredLawyer , authcontroller.accept)
routes.post('/lawyer/request/reject/:id' , requiredAuth,requiredLawyer , authcontroller.reject)

module.exports = routes;