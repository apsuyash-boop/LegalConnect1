const mongoose = require("mongoose");
const User = require("./models/User");

mongoose
  .connect("mongodb://127.0.0.1:27017/lawyerhub")
  .then(async () => {
    const users = [
      {
        username: "John Lawyer",
        email: "johnlawyer@gmail.com",
        password: "123456",
        role: "lawyer",
      },
      {
        username: "David Lawyer",
        email: "davidlawyer@gmail.com",
        password: "123456",
        role: "lawyer",
      },
      {
        username: "Sarah Lawyer",
        email: "sarahlawyer@gmail.com",
        password: "123456",
        role: "lawyer",
      },
      {
        username: "Priya Lawyer",
        email: "priyalawyer@gmail.com",
        password: "123456",
        role: "lawyer",
      },
      {
        username: "Arjun Lawyer",
        email: "arjunlawyer@gmail.com",
        password: "123456",
        role: "lawyer",
      },
      {
        username: "Neha Lawyer",
        email: "nehalawyer@gmail.com",
        password: "123456",
        role: "lawyer",
      },
      {
        username: "Rohan Lawyer",
        email: "rohanlawyer@gmail.com",
        password: "123456",
        role: "lawyer",
      },
      {
        username: "Karan Lawyer",
        email: "karanlawyer@gmail.com",
        password: "123456",
        role: "lawyer",
      },
      {
        username: "Rahul Client",
        email: "rahulclient@gmail.com",
        password: "123456",
        role: "client",
      },
      {
        username: "Amit Client",
        email: "amitclient@gmail.com",
        password: "123456",
        role: "client",
      },
      {
        username: "Sneha Client",
        email: "snehaclient@gmail.com",
        password: "123456",
        role: "client",
      },
      {
        username: "Riya Client",
        email: "riyaclient@gmail.com",
        password: "123456",
        role: "client",
      },
      {
        username: "Vikram Client",
        email: "vikramclient@gmail.com",
        password: "123456",
        role: "client",
      },
      {
        username: "Anjali Client",
        email: "anjaliclient@gmail.com",
        password: "123456",
        role: "client",
      },
      {
        username: "Manish Client",
        email: "manishclient@gmail.com",
        password: "123456",
        role: "client",
      },
    ];

    await User.deleteMany();

    const createdUsers = await User.create(users);

    console.log(createdUsers);

    mongoose.connection.close();
  })
  .catch((err) => console.log(err));
