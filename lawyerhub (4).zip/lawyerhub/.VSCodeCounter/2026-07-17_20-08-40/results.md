# Summary

Date : 2026-07-17 20:08:40

Directory c:\\Users\\ISHAN\\Desktop\\lawyerhub

Total : 20 files,  4322 codes, 0 comments, 465 blanks, all 4787 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 8 | 2,105 | 0 | 315 | 2,420 |
| JSON | 2 | 1,295 | 0 | 2 | 1,297 |
| JavaScript | 10 | 922 | 0 | 148 | 1,070 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 20 | 4,322 | 0 | 465 | 4,787 |
| . (Files) | 6 | 1,741 | 0 | 40 | 1,781 |
| controller | 1 | 172 | 0 | 36 | 208 |
| middelware | 1 | 95 | 0 | 11 | 106 |
| models | 3 | 191 | 0 | 48 | 239 |
| routes | 1 | 18 | 0 | 15 | 33 |
| views | 8 | 2,105 | 0 | 315 | 2,420 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)