# Diff Summary

Date : 2026-07-17 20:08:40

Directory c:\\Users\\ISHAN\\Desktop\\lawyerhub

Total : 8 files,  690 codes, 0 comments, 76 blanks, all 766 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JavaScript | 6 | 490 | 0 | 43 | 533 |
| HTML | 2 | 200 | 0 | 33 | 233 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 8 | 690 | 0 | 76 | 766 |
| . (Files) | 3 | 430 | 0 | 30 | 460 |
| controller | 1 | 50 | 0 | 9 | 59 |
| middelware | 1 | 9 | 0 | 3 | 12 |
| routes | 1 | 1 | 0 | 1 | 2 |
| views | 2 | 200 | 0 | 33 | 233 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)