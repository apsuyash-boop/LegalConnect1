# Diff Details

Date : 2026-07-17 20:08:40

Directory c:\\Users\\ISHAN\\Desktop\\lawyerhub

Total : 8 files,  690 codes, 0 comments, 76 blanks, all 766 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [controller/authControllers.js](/controller/authControllers.js) | JavaScript | 50 | 0 | 9 | 59 |
| [middelware/authMiddelware.js](/middelware/authMiddelware.js) | JavaScript | 9 | 0 | 3 | 12 |
| [routes/authRoutes.js](/routes/authRoutes.js) | JavaScript | 1 | 0 | 1 | 2 |
| [seedClients.js](/seedClients.js) | JavaScript | 131 | 0 | 11 | 142 |
| [seedLawyers.js](/seedLawyers.js) | JavaScript | 196 | 0 | 13 | 209 |
| [seedUser.js](/seedUser.js) | JavaScript | 103 | 0 | 6 | 109 |
| [views/clientProfile.ejs](/views/clientProfile.ejs) | HTML | -1 | 0 | 0 | -1 |
| [views/viewLawyer.ejs](/views/viewLawyer.ejs) | HTML | 201 | 0 | 33 | 234 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details