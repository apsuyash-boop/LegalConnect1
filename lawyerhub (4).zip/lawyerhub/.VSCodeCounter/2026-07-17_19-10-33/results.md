# Summary

Date : 2026-07-17 19:10:33

Directory c:\\Users\\ISHAN\\Desktop\\lawyerhub

Total : 16 files,  3632 codes, 0 comments, 389 blanks, all 4021 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 7 | 1,905 | 0 | 282 | 2,187 |
| JSON | 2 | 1,295 | 0 | 2 | 1,297 |
| JavaScript | 7 | 432 | 0 | 105 | 537 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 16 | 3,632 | 0 | 389 | 4,021 |
| . (Files) | 3 | 1,311 | 0 | 10 | 1,321 |
| controller | 1 | 122 | 0 | 27 | 149 |
| middelware | 1 | 86 | 0 | 8 | 94 |
| models | 3 | 191 | 0 | 48 | 239 |
| routes | 1 | 17 | 0 | 14 | 31 |
| views | 7 | 1,905 | 0 | 282 | 2,187 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)