# Details

Date : 2026-07-17 19:10:33

Directory c:\\Users\\ISHAN\\Desktop\\lawyerhub

Total : 16 files,  3632 codes, 0 comments, 389 blanks, all 4021 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [app.js](/app.js) | JavaScript | 16 | 0 | 8 | 24 |
| [controller/authControllers.js](/controller/authControllers.js) | JavaScript | 122 | 0 | 27 | 149 |
| [middelware/authMiddelware.js](/middelware/authMiddelware.js) | JavaScript | 86 | 0 | 8 | 94 |
| [models/Client.js](/models/Client.js) | JavaScript | 71 | 0 | 18 | 89 |
| [models/Lawyer.js](/models/Lawyer.js) | JavaScript | 78 | 0 | 17 | 95 |
| [models/User.js](/models/User.js) | JavaScript | 42 | 0 | 13 | 55 |
| [package-lock.json](/package-lock.json) | JSON | 1,275 | 0 | 1 | 1,276 |
| [package.json](/package.json) | JSON | 20 | 0 | 1 | 21 |
| [routes/authRoutes.js](/routes/authRoutes.js) | JavaScript | 17 | 0 | 14 | 31 |
| [views/clientDashboard.ejs](/views/clientDashboard.ejs) | HTML | 116 | 0 | 18 | 134 |
| [views/clientProfile.ejs](/views/clientProfile.ejs) | HTML | 552 | 0 | 86 | 638 |
| [views/index.ejs](/views/index.ejs) | HTML | 116 | 0 | 18 | 134 |
| [views/lawyerDashboard.ejs](/views/lawyerDashboard.ejs) | HTML | 162 | 0 | 25 | 187 |
| [views/lawyerProfile.ejs](/views/lawyerProfile.ejs) | HTML | 495 | 0 | 55 | 550 |
| [views/login.ejs](/views/login.ejs) | HTML | 218 | 0 | 38 | 256 |
| [views/signup.ejs](/views/signup.ejs) | HTML | 246 | 0 | 42 | 288 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)