const mongoose = require("mongoose");
const Client = require("./models/Client");

mongoose.connect("mongodb://127.0.0.1:27017/lawyerhub");

const clients = [
  {
    userId: "6a5a377139612fc81b2700e5",
    name: "Rahul Client",
    email: "rahulclient@gmail.com",
    phone: "9876500001",
    about: "Property dispute with landlord regarding eviction notice.",
    legalCategory: ["Property Law"],
    opponentType: "Landlord",
    urgency: "High",
    consultationMode: ["Online"],
    budget: 3000,
    preferredLanguage: ["English", "Hindi"],
    preferredCity: "Chennai",
    caseFiled: "No",
    courtLevel: "Not Applicable",
    additionalNotes: "Need legal advice before filing the case.",
  },

  {
    userId: "6a5a377139612fc81b2700e6",
    name: "Amit Client",
    email: "amitclient@gmail.com",
    phone: "9876500002",
    about: "Company has not paid salary for three months.",
    legalCategory: ["Civil Law"],
    opponentType: "Employer",
    urgency: "Medium",
    consultationMode: ["Online"],
    budget: 2500,
    preferredLanguage: ["English"],
    preferredCity: "Jaipur",
    caseFiled: "No",
    courtLevel: "Not Applicable",
    additionalNotes: "Need help sending a legal notice.",
  },

  {
    userId: "6a5a377139612fc81b2700e7",
    name: "Sneha Client",
    email: "snehaclient@gmail.com",
    phone: "9876500003",
    about: "Looking for divorce and child custody advice.",
    legalCategory: ["Family Law"],
    opponentType: "Family Member",
    urgency: "High",
    consultationMode: ["In Person"],
    budget: 5000,
    preferredLanguage: ["English", "Hindi"],
    preferredCity: "Mumbai",
    caseFiled: "Yes",
    courtLevel: "Family Court",
    additionalNotes: "Need an experienced family lawyer.",
  },

  {
    userId: "6a5a377139612fc81b2700e8",
    name: "Riya Client",
    email: "riyaclient@gmail.com",
    phone: "9876500004",
    about: "Victim of an online financial scam.",
    legalCategory: ["Cyber Law"],
    opponentType: "Individual",
    urgency: "Emergency",
    consultationMode: ["Online"],
    budget: 4000,
    preferredLanguage: ["English"],
    preferredCity: "Hyderabad",
    caseFiled: "Yes",
    courtLevel: "District Court",
    additionalNotes: "Already reported to cyber crime portal.",
  },

  {
    userId: "6a5a377139612fc81b2700e9",
    name: "Vikram Client",
    email: "vikramclient@gmail.com",
    phone: "9876500005",
    about: "Purchased defective electronic product and seller refused refund.",
    legalCategory: ["Consumer Law"],
    opponentType: "Company",
    urgency: "Low",
    consultationMode: ["Either"],
    budget: 2000,
    preferredLanguage: ["English", "Hindi"],
    preferredCity: "Ahmedabad",
    caseFiled: "No",
    courtLevel: "Consumer Court",
    additionalNotes: "Have invoice and warranty documents.",
  },

  {
    userId: "6a5a377139612fc81b2700ea",
    name: "Anjali Client",
    email: "anjaliclient@gmail.com",
    phone: "9876500006",
    about: "Income tax notice received unexpectedly.",
    legalCategory: ["Tax Law"],
    opponentType: "Government",
    urgency: "Medium",
    consultationMode: ["Online"],
    budget: 3500,
    preferredLanguage: ["English"],
    preferredCity: "Pune",
    caseFiled: "No",
    courtLevel: "Not Applicable",
    additionalNotes: "Need tax lawyer for consultation.",
  },

  {
    userId: "6a5a377139612fc81b2700eb",
    name: "Manish Client",
    email: "manishclient@gmail.com",
    phone: "9876500007",
    about: "Business partner breached partnership agreement.",
    legalCategory: ["Corporate Law"],
    opponentType: "Business Partner",
    urgency: "High",
    consultationMode: ["In Person"],
    budget: 8000,
    preferredLanguage: ["English", "Hindi"],
    preferredCity: "Bangalore",
    caseFiled: "Yes",
    courtLevel: "High Court",
    additionalNotes: "Looking for corporate litigation expert.",
  },
];

async function seed() {
  await Client.deleteMany({});
  await Client.insertMany(clients);
  console.log("Clients inserted");
  mongoose.connection.close();
}

seed();
