const express = require('express');
const mongoose = require('mongoose');
const cookie = require('cookie-parser');
const routes = require('./routes/authRoutes')
const {currentuser} = require('./middelware/authMiddelware');

const app = express();

app.set('view engine' , 'ejs');

mongoose.connect("mongodb://localhost:27017/lawyerhub")
.then(() => app.listen(4000))
.then(() => console.log('connected to db'))
.catch((err) => console.log(err));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(cookie());

app.use(currentuser);
app.use(routes);

