const User = require("../models/User");
const Lawyer = require("../models/Lawyer");
const Client = require("../models/Client");
const Consult = require("../models/Consultation");
const jwt = require("jsonwebtoken");

const handelError = (err) => {
  let errors = { email: "", password: "" };

  if (err.message === "Incorrect Email") {
    errors.email = "this email is not register";
  }
  if (err.message === "Incorrect Password") {
    errors.password = "this password is incorrect";
  }

  if (err.code === 11000) {
    errors.email = "this email already exist";
    return errors;
  }

  if (err.message.includes("user validation failed")) {
    Object.values(err.errors).forEach(({ properties }) => {
      errors[properties.path] = properties.message;
    });
  }

  return errors;
};

const createtoken = (id) => {
  return jwt.sign({ id }, "ishan");
};

module.exports.home_get = async (req, res) => {
  res.render("index", {
    companyName: "LawyersHub",
    username: "Ishan", // Pass null or omit to default to 'Guest'
  });
};

module.exports.about = (req,res) =>{
  res.render("aboutus")
}
module.exports.contact = (req,res) =>{
  res.render("contactus")
}

module.exports.signup_get = async (req, res) => {
  res.render("signup");
};

module.exports.signup_post = async (req, res) => {
  const { username, email, password, role } = req.body;

  try {
    const user = await User.create({ username, email, password, role });

    const token = createtoken(user._id);
    res.cookie("jwt", token, { httpOnly: true });

    res.status(200).json({ 
      user: user._id,
      role: user.role
    });

  } catch (err) {
    const handelerror = handelError(err);
    res.status(400).json({ errors: handelerror });
  }
};

module.exports.login_get = async (req, res) => {
  res.render("login");
};

module.exports.login_post = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.login(email, password);
    const token = createtoken(user._id);
    res.cookie("jwt", token, { httpOnly: true });
    res.status(200).json({ user: user._id, role: user.role });
  } catch (err) {
    const handelerror = handelError(err);
    res.status(400).json({ errors: handelerror });
  }
};

module.exports.logout_get = (req, res) => {
  res.cookie("jwt", "", { maxAge: 1 });
  res.redirect("/");
};

module.exports.lawyer_get = async (req, res) => {
  try {
    const lawyer = await Lawyer.findOne({ userId: req.user._id });
    const lawyerUserId = req.user._id;

        const requests = await Consult.find({
    lawyerId: lawyerUserId,
    status: "Accepted"
}).populate("clientProfile");

    if (lawyer) {
      return res.render("lawyerDashboard", {
        user: req.user,
        lawyer,
        requests,
      });
    }

    return res.render("lawyerProfile", {
      user: req.user,
    });
  } catch (err) {
    console.log(err);
    res.status(500).send("Server Error");
  }
};

module.exports.lawyer_profile_post = async (req, res) => {
  try {
    const data = req.body;
    const userId = req.user._id;

    const lawyerExist = await Lawyer.findOne({ userId });

    if (lawyerExist) {
      return res.status(400).json({
        success: false,
        message: "Profile already exists",
      });
    }

    const lawyer = await Lawyer.create({
      userId,
      ...data,
    });

    return res.status(200).json({
      success: true,
      lawyer: lawyer._id,
    });
  } catch (err) {
    console.log(err);
    return res.status(400).json({
      success: false,
      message: "Something went wrong",
    });
  }
};
module.exports.client_get = async (req, res) => {
  try {
    const client = await Client.findOne({ userId: req.user._id });

    if (!client) {
      return res.render("clientProfile", {
        user: req.user,
      });
    }

    // Get all consultation requests made by this client
    const consultations = await Consult.find({
      clientId: req.user._id,
    })
      .populate("lawyerId") // if lawyerId references User
      .sort({ createdAt: -1 });

    return res.render("clientDashboard", {
      user: req.user,
      client,
      consultations,
    });
  } catch (err) {
    console.log(err);
    res.status(500).send("Server Error");
  }
};

module.exports.client_profile_post = async (req, res, next) => {
  try {
    const data = req.body;
    const userId = req.user._id;

    const clientExist = await Client.findOne({ userId });

    if (clientExist) {
      return res.status(400).json({
        success: false,
        message: "Profile already exists",
      });
    }

    const client = await Client.create({
      userId,
      ...data,
    });

    return res.status(200).json({
      success: true,
      client: client._id,
    });
  } catch (err) {
    console.log(err);
    return res.status(400).json({
      success: false,
      message: "Something went wrong",
    });
  }
};

module.exports.client_lawyer_get = async (req, res) => {
  try {
    const userId = req.user._id;

    const client = await Client.findOne({ userId });

    if (!client) {
      return res.redirect("/client");
    }

    let lawyers = await Lawyer.find({
      specialization: {
        $in: client.legalCategory,
      },
      city: client.preferredCity,
    });

    const filteredLawyers = [];

    for (const lawyer of lawyers) {
      const consultation = await Consult.findOne({
        clientId: userId,
        lawyerId: lawyer.userId,
      });

      if (!consultation || consultation.status !== "Rejected") {
        filteredLawyers.push(lawyer);
      }
    }

    res.render("viewLawyer", {
      user: req.user,
      client,
      lawyers: filteredLawyers,
    });

  } catch (err) {
    console.log(err);
    res.redirect("/client");
  }
};

module.exports.viewLawyerProfile = async (req, res, next) => {
  try {
    const userid = req.params.id;
    const lawyer = await Lawyer.findById(userid);

    if (!lawyer) {
      return res.status(404).send("Lawyer not found");
    } else {
      res.render("viewLawyerProfile", { lawyer });
    }
  } catch (err) {
    console.log(err);
    res.status(500).send("Server Error");
  }
};

module.exports.requestConsultation = async (req, res) => {
  try {
    const clientid = req.user._id;
    const lawyerid = req.params.lawyerId;

    const client = await Client.findOne({
      userId: clientid,
    });

    const lawyer = await Lawyer.findById(lawyerid);

    if (!client || !lawyer) {
      return res.status(400).send("Profile not found");
    }

    await Consult.create({
      clientId: clientid,
      lawyerId: lawyer.userId,
      clientProfile: client._id,
      lawyerProfile: lawyer._id,
      message: "Client requested consultation",
    });

    res.redirect("/client");
  } catch (err) {
    console.log(err);
    res.status(400).send("Error");
  }
};

module.exports.lawyer_requests_get = async(req,res)=>{
    try{

        const lawyerUserId = req.user._id;

        const requests = await Consult
        .find({
            lawyerId: lawyerUserId
        })
        .populate("clientProfile");


        res.render("viewClients",{
            requests,
            user:req.user
        });

    }
    catch(err){
        console.log(err);
        res.status(400).send("Error");
    }
}

module.exports.accept = async (req,res) =>{
  try {
    const id = req.params.id;
    const consult = await Consult.findById(id);

    if(!consult){
      return res.status(404).send("Consult not found");
    }
    else{
      if(consult.status === 'Pending'){
        consult.status = 'Accepted';
        await consult.save();
        res.redirect("/lawyer/requests");
      }
    }


  } catch (err) {
    console.log(err)
  }
}

module.exports.reject = async (req,res) =>{
    try {
    const id = req.params.id;
    const consult = await Consult.findById(id);

    if(!consult){
      return res.status(404).send("Consult not found");
    }
    else{
      if(consult.status === 'Pending'){
        consult.status = 'Rejected';
        await consult.save();
        res.redirect("/lawyer/requests");
      }
    }


  } catch (err) {
    console.log(err)
  }
}
